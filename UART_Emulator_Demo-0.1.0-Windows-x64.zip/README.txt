UART Emulator Demo for Windows
==============================

This package contains build instructions and tools for running the UART Emulator Demo on Windows.

## 🚀 Quick Start (Recommended)

### Option 1: WSL (Easiest)
1. Install WSL: Open PowerShell as Administrator and run: wsl --install
2. Restart Windows
3. In WSL terminal: sudo apt install build-essential libglfw3-dev libgl1-mesa-dev
4. Clone the repository and build: make demo && ./bin/demo

### Option 2: Native Windows Build
1. Follow the instructions in WINDOWS-BUILD-INSTRUCTIONS.md
2. Install Visual Studio Build Tools or MinGW-w64
3. Download GLFW library
4. Build using the provided commands

## 📋 Package Contents

- WINDOWS-BUILD-INSTRUCTIONS.md - Detailed build guide
- build-windows.bat - Windows build helper script
- run-demo-wsl.bat - WSL launcher script
- README.txt - This file

## 🎯 Features

- UART hardware simulation
- Real-time communication visualization
- Modern GUI interface
- Cross-platform compatibility

## 🔗 More Information

- GitHub Repository: https://github.com/Mathieu-Poirier/UART_EMU_V2
- Linux AppImage: Available in the main release
- Issues: Report problems on GitHub

## 💡 Tips

- WSL provides the easiest Windows experience
- No complex library setup required
- Full compatibility with Linux version
- GUI works with X11 server (VcXsrv, Xming)
